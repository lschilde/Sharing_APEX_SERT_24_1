PROMPT == LOGGER
@logger/logger_install.sql
